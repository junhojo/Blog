const EllipticCurve = {
    Secp256k1: 'secp256k1',
    Secp256r1: 'secp256r1',
    Ed25519: 'ed25519',
};

export { EllipticCurve };
