export default () => ({
    recordError: jest.fn(),
});
