const { setDefaultTimeout } = require('@cucumber/cucumber');

setDefaultTimeout(400 * 1000);
