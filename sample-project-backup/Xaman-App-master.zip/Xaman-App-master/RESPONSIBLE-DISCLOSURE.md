# Xaman Responsible Disclosure

See:
https://github.com/XRPL-Labs/Xaman-Issue-Tracker/blob/master/RESPONSIBLE-DISCLOSURE.md
