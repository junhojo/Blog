#import <React/RCTBridgeModule.h>

@interface AppUpdateModule : NSObject <RCTBridgeModule>

@end
