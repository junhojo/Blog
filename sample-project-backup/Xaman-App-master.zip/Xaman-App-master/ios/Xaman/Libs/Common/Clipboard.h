#import <React/RCTBridgeModule.h>

@interface ClipboardModule : NSObject <RCTBridgeModule>

@end
