#import <React/RCTBridgeModule.h>

@interface SharedPreferencesModule : NSObject <RCTBridgeModule>

@end
