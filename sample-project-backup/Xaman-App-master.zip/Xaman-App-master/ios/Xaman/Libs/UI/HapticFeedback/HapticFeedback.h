#import <Foundation/Foundation.h>

#import <React/RCTBridgeModule.h>

@interface HapticFeedbackModule : NSObject <RCTBridgeModule>

@end
