#import <React/RCTViewManager.h>

@interface BlurViewManager : RCTViewManager

@end
