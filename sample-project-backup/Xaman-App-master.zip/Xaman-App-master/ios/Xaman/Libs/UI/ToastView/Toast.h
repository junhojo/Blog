#import <React/RCTBridgeModule.h>

@interface Toast : NSObject <RCTBridgeModule>

@end
