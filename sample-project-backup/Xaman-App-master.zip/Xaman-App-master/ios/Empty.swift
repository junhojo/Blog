//
//  Empty.swift
//  Xaman
//
//  Created by XRPL Labs on 26/11/2020.
//

import Foundation
