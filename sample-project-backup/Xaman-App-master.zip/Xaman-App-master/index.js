// import './.cosmos/cosmos.app';

import './debug';
import './global';

import Application from './src/app';

// run the app
Application.run();
